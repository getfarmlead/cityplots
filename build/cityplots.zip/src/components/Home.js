import React from 'react';
import Slider from './Slider';
import Productslider from './Productslider';

function Home() {
    return (
        <>
        <Slider/>
        <Productslider/>
        </>
    );
}

export default Home;
