
import React from 'react';
import Carousel from 'react-bootstrap/Carousel';

import mainbanner from '../images/mainbanner.svg';

function Slider() 
{
    return (
        <>
            <div className="home-slider">
                <img src={mainbanner} className="img-fluid" />
            </div>
        </>
    );
}

export default Slider;
