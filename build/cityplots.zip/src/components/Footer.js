import React from 'react';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import footerlogo from '../images/footerlogo.png';
import Button from 'react-bootstrap/Button';
import facebookic from '../images/facebookic.svg';
import instagram from '../images/instagram.svg';
import twitter from '../images/twitter.svg';
import youtube from '../images/youtube.svg';
import AOS from 'aos';
import 'aos/dist/aos.css';
import { useEffect } from 'react';

function Footer() {
    useEffect(() => 
    {
        AOS.init();
    }, [])
    return (
        <>
        <div class="footer" data-aos="fade-up">
            <div class="footer_section">
                <div class="container-fluid footer-bg">
                    <Container>
                    <Row>
                        {/* <Col className="footer-logo">
                            <p>Copyrights @ 2022</p>
                        </Col>
                        <Col className="footer-menu">
                            <ul className="footer_icon">
                                <li><Facebook color='var(--white)' size={16}/></li>
                                <li><Twitter color='var(--white)' size={16}/></li>
                                <li><Instagram color='var(--white)' size={16}/></li>
                                <li><Linkedin color='var(--white)' size={16}/></li>
                                <li><Youtube color='var(--white)' size={16}/></li>
                            </ul>
                        </Col>
                        <Col className='text-left'>
                            <p>Copyrights @ 2022</p>
                        </Col>
                        <Col className="footer-social">
                            <p>2023 Cityplots. All rights reserved</p>
                        </Col> */}

                        <Col xs={12} md={4}>
                            <div className="footer-logo">
                                <img src={footerlogo} alt="" />
                                <p>Cityplots is not your typical organization next door. We are a pioneering tech company that is revolutionizing the way people find and purchase plots.</p>
                            </div>
                        </Col>
                        <Col sm={8}>
                            <Row>
                                <Col xs={12} md={4}>
                                    <div className="footer-menu">
                                        <h3>Links</h3>
                                        <div className="footer-list">
                                            <ul>
                                                <li>Home</li>
                                                <li>Services</li>
                                                <li>About Us</li>
                                            </ul>
                                        </div>
                                    </div>
                                </Col>
                                <Col xs={12} md={4}>
                                    <div className="footer-menu">
                                        <h3>Legal</h3>
                                        <div className="footer-list">
                                            <ul>
                                                <li>Terms of use</li>
                                                <li>Terms of conditions</li>
                                                <li>Privecy policy</li>
                                                <li>Cookie policy</li>
                                            </ul>
                                        </div>
                                    </div>
                                </Col>
                                <Col xs={12} md={4}>
                                    <div className="footer-social">
                                            <div className="social">
                                                <Button variant="primary">Get in touch with us</Button>
                                            </div>
                                            <div className="social-list">
                                                <ul>
                                                    <li><img src={instagram} alt=""/></li>
                                                    <li><img src={facebookic} alt=""/></li>
                                                    <li><img src={twitter} alt=""/></li>
                                                    <li><img src={youtube} alt=""/></li>
                                                </ul>
                                            </div>
                                            <div className="socialcopy">
                                                <p>2023 Cityplots. All rights reserved</p>
                                            </div>
                                    </div>
                                </Col>
                            </Row>
                        </Col>

                    </Row>
                </Container>
                </div>
            </div>
        </div>
        </>
    );
}

export default Footer;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       